sigma=1.000;  
eta=2.5;    
beta=0.99;   
alpha=0.67;   
omega=1;    
delta=0.025; 
theta=6.7;    
sig_v= 0.604; 
varphi=0.3;  
phih=0.8;
phil=0.1;
sig_c=0.05;
 
  m      =beta;
  vh     =1.75;
  psh    =1;
  ph     =(exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)...
           +vh^(1-1/theta)*exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vh)/sig_v))^(1/(1-theta)) * psh;
  ch     =1;
  ah     =vh/((psh/ph)^theta)*ch ;
  qh      =exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)*(psh/ph)^(-theta)*ch+(1-normcdf(log(vh)/sig_v))*ah;
  rih     =(1-delta)*m;
  muh     =(1-rih)/(1-normcdf(log(vh)/sig_v))+rih;
    
   	  