function F=sect(X)
    
global     sigma eta beta alpha omega ...
           delta theta sig_v...
		   varphi phih phil sig_c...
           omega1 omega2 R m A rih ril;

pmh=X(1);
pmhn=X(2);
zeh=X(3);
zsh=X(4);
Egh=X(5);
Ezgh=X(6);
ch=X(7);
qh=X(8);
ah=X(9);
ph=X(10);
psh=X(11);
yh=X(12);
muh=X(13);
vh=X(14);


pml=X(15);
pmln=X(16);
zel=X(17);
zsl=X(18);
Egl=X(19);
Ezgl=X(20);
cl=X(21);
ql=X(22);
al=X(23);
pl=X(24);
psl=X(25);
yl=X(26);
mul=X(27);
vl=X(28);

hh=X(29);
hl=X(30);

c=X(31);
n=X(32);
w=X(33);
p=X(34);


%high h sector 
F(1)=((pmh*yh)/((yh+phih)^(1/alpha)))*(A/(w*R))-zeh;

F(2)=(log(zeh)+0.5*sig_c^2)/sig_c-zsh;

F(3)=1 + varphi/(1-varphi)*(1-normcdf(zsh))-Egh;

F(4)=1 + varphi/(1-varphi)*(1-normcdf(zsh-sig_c))-Ezgh;

F(5)=(Ezgh/Egh)*(w*R/(alpha*A))*(yh+phih)^((1-alpha)/alpha)-pmh;

F(6)=((yh+phih)/exp(0.5*alpha*(1+alpha)*sig_c^2))^(1/alpha)/A-hh;

F(7)=pmh*p-pmhn;

F(8)=ah-(1-delta)*(ah-qh)-yh;

F(9)=muh*pmhn-psh;

F(10)=(ah/ch)*(psh/ph)^theta-vh;

F(11)=(1-rih)/(1-normcdf(log(vh)/sig_v))+rih-muh;

F(12)=(1/(1 + (qh/...
         ((-theta)*exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)*(psh/ph)^(-theta)*ch))))...
        *(1-delta)*m*pmhn-psh; 

F(13)=exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)*(psh/ph)^(-theta)*ch+(1-normcdf(log(vh)/sig_v))*ah-qh;

F(14)=(exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)+...
     vh^(1-1/theta)*exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vh)/sig_v))^(1/(1-theta)) *psh-ph;


%low h sector 
F(15)=(Ezgl/Egl)*(w*R/(alpha*A))*(yl+phil)^((1-alpha)/alpha)-pml;

F(16)=1 + varphi/(1-varphi)*(1-normcdf(zsl-sig_c))-Ezgl;

F(17)=1 + varphi/(1-varphi)*(1-normcdf(zsl))-Egl;

F(18)=(log(zel)+0.5*sig_c^2)/sig_c-zsl;

F(19)=((pml*yl)/((yl+phil)^(1/alpha)))*(A/(w*R))-zel;

F(20)=pml*p-pmln;

F(21)=mul*pmln-psl;

F(22)=(1-ril)/(1-normcdf(log(vl)/sig_v))+ril-mul;

F(23)=(1/(1 + (ql/...
         ((-theta)*exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v)*(psl/pl)^(-theta)*cl))))...
        *(1-delta)*m*pmln-psl; 

F(24)=(exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v)+...
     vl^(1-1/theta)*exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vl)/sig_v))^(1/(1-theta)) *psl-pl;

F(25)=(al/cl)*(psl/pl)^theta-vl;

F(26)=al-(1-delta)*(al-ql)-yl;

F(27)=exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v)*(psl/pl)^(-theta)*cl+(1-normcdf(log(vl)/sig_v))*al-ql;

%aggregates
F(28)=(omega1)^(-omega1)*ch^(omega1)*omega2^(-omega2)*cl^(omega2)-c;

F(29)=omega*c^sigma*n^eta-w;

F(30)=ph^omega1*pl^omega2-p;

F(31)=omega1*pl/(omega2*ph)-ch/cl;

F(32)=hh+hl-n;

F(33)=((yl+phil)/exp(0.5*alpha*(1+alpha)*sig_c^2))^(1/alpha)/A-hl;

F(34)=ah*(vh^(1/theta-1)*exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)...
      + exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vh)/sig_v))^(theta/(theta-1))-ch;
  
%F(34)=al*(vl^(1/theta-1)*exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v)...  
%      +exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vl)/sig_v))^(theta/(theta-1));


end 