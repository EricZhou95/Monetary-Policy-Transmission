beta=0.99;   
m=beta;  
delta=0.025; 
theta=6.7;    
sig_v= 0.604; 
ri  =(1-delta)*m;

X=[1.5, 1.75,0.9870,1.6030];

options  = optimset('LargeScale','off','display','off',...
           'MaxIter',5000,'MaxFunEvals',5000,'TolX',1e-10,...
           'TolFun',1e-10);

X=fsolve(@inv,X,options);
 
mu=X(1);
v=X(2);
p=X(3);
a=X(4);

c=1; %exogeneous 
pm=1.9579;  %exogeneous 

ps=mu*pm;

q = exp(sig_v^2/2)*normcdf(log(v)/sig_v-sig_v)*(ps/p)^(-theta)*c+(1-normcdf(log(v)/sig_v))*a;
inven=a-q;
is1=inven/q;
y=a-(1-delta)*inven;


function F=inv(X) 
mu=X(1);
v=X(2);
p=X(3);
a=X(4);


beta=0.99;   
m=beta;  
delta=0.025; 
theta=6.7;    
sig_v= 0.604; 
ri  =(1-delta)*m;
c=1; %exogeneous 
pm=0.9;

F(1)=(1-ri)/(1-normcdf(log(v)/sig_v))+ri-mu;

F(2)=(theta/(theta-1-v*(1-normcdf(log(v)/sig_v))/(exp(sig_v^2/2)*normcdf(log(v)/sig_v-sig_v))))*(1-delta)*m-mu*pm;

F(3)=(exp(sig_v^2/2)*normcdf(log(v)/sig_v-sig_v)+...
     v^(1-1/theta)*exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(v)/sig_v))^(1/(1-theta)) * mu*pm-p;

F(4)=(a/c)*(mu*pm/p)^theta-v;

end 



