A=1;
beta=0.99;
R=1/beta;
sig_c=0.05;
varphi=0.03;
phih=0.8;
yh=0.9;
w=1;
alpha=0.67;

X=[1,1,1,1,1];

options  = optimset('LargeScale','off','display','off',...
           'MaxIter',5000,'MaxFunEvals',5000,'TolX',1e-10,...
           'TolFun',1e-10);

X=fsolve(@css,X,options);

X

function F=css(X)

A=1;
beta=0.99;
R=1/beta;
sig_c=0.05;
varphi=0.03;
phih=0.8;
yh=0.9;
w=1;
alpha=0.67;


pmh=X(1);
Ezgh=X(2);
Egh=X(3);
zsh=X(4);
zeh=X(5);


F(1)=(Ezgh/Egh)*(w*R/(alpha*A))*(yh+phih)^((1-alpha)/alpha)-pmh;

F(2)=1 + varphi/(1-varphi)*(1-normcdf(zsh-sig_c))-Ezgh;

F(3)=1 + varphi/(1-varphi)*(1-normcdf(zsh))-Egh;

F(4)=(log(zeh)+0.5*sig_c^2)/sig_c-zsh;

F(5)=((pmh*yh)/((yh+phih)^(1/alpha)))*(A/(w*R))-zeh;


end 