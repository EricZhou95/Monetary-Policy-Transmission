global  sigma eta beta alpha omega ...
           delta theta sig_v...
		   varphi phih phil sig_c...
          c n w pi R m A p rih;
     
sigma=1.000;   
eta=2.5;         
alpha=0.67; 
omega=1;   
delta=0.025;
theta=5; 
sig_v=0.7; 
varphi=0.3;  
phih=0.1;
phil=0.1;
sig_c=0.05; 
A=1;

%exogeneous 
c=1;
w=1;
p=1;
beta=0.99;
m=beta;
R=1/beta;
rih=(1-delta)*m;

options  = optimset('LargeScale','off','display','off',...
           'MaxIter',5000,'MaxFunEvals',5000,'TolX',1e-10,...
           'TolFun',1e-10);

X=[2.0068,1.4285,1.4285,-3.8354,0.8245,2.0462,1.0197,0.8070,2.1447,1.1062,0.9873,1];
X=fsolve(@sector,X,options);


function F=sector(X)
global  sigma eta beta alpha omega ...
           delta theta sig_v...
		   varphi phih phil sig_c...
          c n w pi R m A p rih;


pmh=X(1);
Ezgh=X(2);
Egh=X(3);
zsh=X(4);
zeh=X(5);
psh=X(6);
muh=X(7);
vh=X(8);
ph=X(9);
ah=X(10);
yh=X(11);
qh=X(12);



F(1)=(Ezgh/Egh)*(w*R/(alpha*A))*(yh+phih)^((1-alpha)/alpha)-pmh;

F(2)=1 + varphi/(1-varphi)*(1-normcdf(zsh-sig_c))-Ezgh;

F(3)=1 + varphi/(1-varphi)*(1-normcdf(zsh))-Egh;

F(4)=(log(zeh)+0.5*sig_c^2)/sig_c-zsh;

F(5)=((pmh*yh)/((yh+phih)^(1/alpha)))*(A/(w*R))-zeh;

F(6)=muh*pmh-psh;

F(7)=(1-rih)/(1-normcdf(log(vh)/sig_v))+rih-muh;

F(8)=(theta/(theta-1-vh*(1-normcdf(log(vh)/sig_v))/(exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v))))*(1-delta)*m-psh; 

F(9)=(exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)+...
     vh^(1-1/theta)*exp(sig_v^2/(2*theta^2))*normcdf(sig_v/theta-log(vh)/sig_v))^(1/(1-theta)) *psh-ph;

F(10)=(ah/c)*(psh/ph)^theta-vh;

F(11)=ah-(1-delta)*(ah-qh)-yh;

F(12)=exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)*(psh/ph)^(-theta)*c+(1-normcdf(log(vh)/sig_v))*ah-qh;


end 