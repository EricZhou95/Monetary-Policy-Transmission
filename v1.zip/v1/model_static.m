function [residual, g1, g2, g3] = model_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations.
%                                          Dynare may prepend or append auxiliary equations, see M_.aux_vars
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%   g3        [M_.endo_nbr by (M_.endo_nbr)^3] double   Third derivatives matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 48, 1);

%
% Model equations
%

T19 = y(5)^params(15);
T25 = 1/params(3)*y(4)^params(16);
T27 = T25^(1-params(15));
T40 = params(5)*y(1)^params(1);
T43 = y(2)^params(2);
T54 = params(19)^(-params(19));
T60 = params(20)^(-params(20));
T61 = T54*y(16)^params(19)*T60;
T63 = y(36)^params(20);
T68 = y(20)^params(19);
T70 = y(40)^params(20);
T90 = 1/params(4);
T91 = (y(22)+params(10))^T90;
T92 = y(9)*y(22)/T91;
T94 = y(7)/(y(5)*y(3));
T101 = params(12)^2;
T109 = params(9)/(1-params(9));
T122 = y(14)/y(13);
T124 = y(5)*y(3)/(y(7)*params(4));
T127 = (1-params(4))/params(4);
T128 = (y(22)+params(10))^T127;
T137 = ((y(22)+params(10))/exp(T101*params(4)*0.5*(1+params(4))))^T90;
T149 = log(y(26))/params(8);
T150 = normcdf(T149,0,1);
T152 = params(8)^2;
T154 = exp(T152/2);
T156 = normcdf(T149-params(8),0,1);
T157 = T154*T156;
T182 = y(21)/y(20);
T184 = T182^params(7);
T206 = y(17)-y(16)*y(28)*params(13)*(y(28)-1)+y(16)*y(28)*(y(28)-1)*y(6)*params(13);
T210 = T182^(-params(7));
T214 = 1+T206/(y(16)*T156*T154*(-params(7))*T210);
T216 = (1-params(6))*1/T214;
T226 = 1-1/params(7);
T231 = exp(T152/(2*params(7)^2));
T232 = y(26)^T226*T231;
T235 = normcdf(params(8)/params(7)-T149,0,1);
T239 = 1/(1-params(7));
T240 = (T157+T232*T235)^T239;
T249 = (y(42)+params(11))^T90;
T250 = y(29)*y(42)/T249;
T271 = y(34)/y(33);
T273 = (y(42)+params(11))^T127;
T277 = ((y(42)+params(11))/exp(T101*params(4)*0.5*(1+params(4))))^T90;
T288 = log(y(46))/params(8);
T289 = normcdf(T288,0,1);
T292 = normcdf(T288-params(8),0,1);
T293 = T154*T292;
T316 = y(41)/y(40);
T317 = T316^params(7);
T336 = y(37)-y(36)*y(48)*params(13)*(y(48)-1)+y(36)*y(48)*y(6)*params(13)*(y(48)-1);
T338 = T316^(-params(7));
T342 = 1+T336/(y(36)*T154*(-params(7))*T292*T338);
T344 = (1-params(6))*1/T342;
T354 = T231*y(46)^T226;
T356 = normcdf(params(8)/params(7)-T288,0,1);
T359 = (T293+T354*T356)^T239;
lhs =log(y(7));
rhs =log(y(7))*params(14)+params(17)*x(1);
residual(1)= lhs-rhs;
lhs =y(5);
rhs =T19*T27*exp(params(18)*x(2));
residual(2)= lhs-rhs;
lhs =y(3);
rhs =T40*T43;
residual(3)= lhs-rhs;
lhs =1;
rhs =y(5)*y(6)/y(4);
residual(4)= lhs-rhs;
lhs =y(6);
rhs =params(3);
residual(5)= lhs-rhs;
lhs =y(1);
rhs =T61*T63;
residual(6)= lhs-rhs;
lhs =y(8);
rhs =T68*T70;
residual(7)= lhs-rhs;
lhs =y(16)/y(36);
rhs =params(19)*y(40)/(params(20)*y(20));
residual(8)= lhs-rhs;
lhs =y(4);
rhs =1;
residual(9)= lhs-rhs;
lhs =y(2);
rhs =y(15)+y(35);
residual(10)= lhs-rhs;
lhs =y(11);
rhs =T92*T94;
residual(11)= lhs-rhs;
lhs =y(12);
rhs =(log(y(11))+0.5*T101)/params(12);
residual(12)= lhs-rhs;
lhs =y(13);
rhs =1+T109*(1-normcdf(y(12),0,1));
residual(13)= lhs-rhs;
lhs =y(14);
rhs =1+T109*(1-normcdf(y(12)-params(12),0,1));
residual(14)= lhs-rhs;
lhs =y(9);
rhs =T122*T124*T128;
residual(15)= lhs-rhs;
lhs =y(15);
rhs =T137/y(7);
residual(16)= lhs-rhs;
lhs =y(10);
rhs =y(8)*y(9);
residual(17)= lhs-rhs;
lhs =y(28);
rhs =1;
residual(18)= lhs-rhs;
lhs =y(27);
rhs =(y(26)*T150-T157)/(T157+y(26)*(1-T150));
residual(19)= lhs-rhs;
lhs =y(18);
rhs =y(19)-y(17);
residual(20)= lhs-rhs;
lhs =y(22);
rhs =y(19)-y(18)*(1-params(6));
residual(21)= lhs-rhs;
lhs =y(23);
rhs =y(18)/y(17);
residual(22)= lhs-rhs;
lhs =y(25);
rhs =y(21)/y(10);
residual(23)= lhs-rhs;
lhs =y(26);
rhs =y(19)/y(16)*T184;
residual(24)= lhs-rhs;
lhs =y(24);
rhs =y(6)*(1-params(6));
residual(25)= lhs-rhs;
lhs =0;
rhs =T150-1+(1-y(24))/(y(25)-y(24));
residual(26)= lhs-rhs;
lhs =y(21);
rhs =y(10)*y(6)*T216;
residual(27)= lhs-rhs;
lhs =y(17);
rhs =y(16)*T157*T210+(1-T150)*y(19);
residual(28)= lhs-rhs;
lhs =y(20);
rhs =y(21)*T240;
residual(29)= lhs-rhs;
lhs =y(31);
rhs =T94*T250;
residual(30)= lhs-rhs;
lhs =y(32);
rhs =(0.5*T101+log(y(31)))/params(12);
residual(31)= lhs-rhs;
lhs =y(33);
rhs =1+T109*(1-normcdf(y(32),0,1));
residual(32)= lhs-rhs;
lhs =y(34);
rhs =1+T109*(1-normcdf(y(32)-params(12),0,1));
residual(33)= lhs-rhs;
lhs =y(29);
rhs =T124*T271*T273;
residual(34)= lhs-rhs;
lhs =y(35);
rhs =T277/y(7);
residual(35)= lhs-rhs;
lhs =y(30);
rhs =y(8)*y(29);
residual(36)= lhs-rhs;
lhs =y(48);
rhs =1;
residual(37)= lhs-rhs;
lhs =y(47);
rhs =(y(46)*T289-T293)/(T293+y(46)*(1-T289));
residual(38)= lhs-rhs;
lhs =y(38);
rhs =y(39)-y(37);
residual(39)= lhs-rhs;
lhs =y(42);
rhs =y(39)-(1-params(6))*y(38);
residual(40)= lhs-rhs;
lhs =y(43);
rhs =y(38)/y(37);
residual(41)= lhs-rhs;
lhs =y(45);
rhs =y(41)/y(30);
residual(42)= lhs-rhs;
lhs =y(46);
rhs =y(39)/y(36)*T317;
residual(43)= lhs-rhs;
lhs =y(44);
rhs =y(6)*(1-params(6));
residual(44)= lhs-rhs;
lhs =0;
rhs =T289-1+(1-y(44))/(y(45)-y(44));
residual(45)= lhs-rhs;
lhs =y(41);
rhs =y(30)*y(6)*T344;
residual(46)= lhs-rhs;
lhs =y(37);
rhs =y(36)*T293*T338+(1-T289)*y(39);
residual(47)= lhs-rhs;
lhs =y(40);
rhs =y(41)*T359;
residual(48)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(48, 48);

  %
  % Jacobian matrix
  %

T519 = y(16)*T156*T154*(-params(7))*T210*y(16)*T156*T154*(-params(7))*T210;
T555 = getPowerDeriv(T182,params(7),1);
T559 = getPowerDeriv(T182,(-params(7)),1);
T622 = 1/y(26)/params(8);
T628 = T622*exp((-(T149*T149))/2)/2.506628274631;
T636 = T622*exp((-((T149-params(8))*(T149-params(8))))/2)/2.506628274631;
T637 = T154*T636;
T750 = y(36)*T154*(-params(7))*T292*T338*y(36)*T154*(-params(7))*T292*T338;
T782 = getPowerDeriv(T316,params(7),1);
T786 = getPowerDeriv(T316,(-params(7)),1);
T848 = 1/y(46)/params(8);
T854 = T848*exp((-(T288*T288))/2)/2.506628274631;
T862 = T848*exp((-((T288-params(8))*(T288-params(8))))/2)/2.506628274631;
T863 = T154*T862;
  g1(1,7)=1/y(7)-params(14)*1/y(7);
  g1(2,4)=(-(exp(params(18)*x(2))*T19*1/params(3)*getPowerDeriv(y(4),params(16),1)*getPowerDeriv(T25,1-params(15),1)));
  g1(2,5)=1-exp(params(18)*x(2))*T27*getPowerDeriv(y(5),params(15),1);
  g1(3,1)=(-(T43*params(5)*getPowerDeriv(y(1),params(1),1)));
  g1(3,2)=(-(T40*getPowerDeriv(y(2),params(2),1)));
  g1(3,3)=1;
  g1(4,4)=(-((-(y(5)*y(6)))/(y(4)*y(4))));
  g1(4,5)=(-(y(6)/y(4)));
  g1(4,6)=(-(y(5)/y(4)));
  g1(5,6)=1;
  g1(6,1)=1;
  g1(6,16)=(-(T63*T60*T54*getPowerDeriv(y(16),params(19),1)));
  g1(6,36)=(-(T61*getPowerDeriv(y(36),params(20),1)));
  g1(7,8)=1;
  g1(7,20)=(-(T70*getPowerDeriv(y(20),params(19),1)));
  g1(7,40)=(-(T68*getPowerDeriv(y(40),params(20),1)));
  g1(8,16)=1/y(36);
  g1(8,20)=(-((-(params(20)*params(19)*y(40)))/(params(20)*y(20)*params(20)*y(20))));
  g1(8,36)=(-y(16))/(y(36)*y(36));
  g1(8,40)=(-(params(19)/(params(20)*y(20))));
  g1(9,4)=1;
  g1(10,2)=1;
  g1(10,15)=(-1);
  g1(10,35)=(-1);
  g1(11,3)=(-(T92*(-(y(7)*y(5)))/(y(5)*y(3)*y(5)*y(3))));
  g1(11,5)=(-(T92*(-(y(7)*y(3)))/(y(5)*y(3)*y(5)*y(3))));
  g1(11,7)=(-(T92*1/(y(5)*y(3))));
  g1(11,9)=(-(T94*y(22)/T91));
  g1(11,11)=1;
  g1(11,22)=(-(T94*(y(9)*T91-y(9)*y(22)*getPowerDeriv(y(22)+params(10),T90,1))/(T91*T91)));
  g1(12,11)=(-(1/y(11)/params(12)));
  g1(12,12)=1;
  g1(13,12)=(-(T109*(-(exp((-(y(12)*y(12)))/2)/2.506628274631))));
  g1(13,13)=1;
  g1(14,12)=(-(T109*(-(exp((-((y(12)-params(12))*(y(12)-params(12))))/2)/2.506628274631))));
  g1(14,14)=1;
  g1(15,3)=(-(T128*T122*y(5)/(y(7)*params(4))));
  g1(15,5)=(-(T128*T122*y(3)/(y(7)*params(4))));
  g1(15,7)=(-(T128*T122*(-(params(4)*y(5)*y(3)))/(y(7)*params(4)*y(7)*params(4))));
  g1(15,9)=1;
  g1(15,13)=(-(T128*T124*(-y(14))/(y(13)*y(13))));
  g1(15,14)=(-(T128*T124*1/y(13)));
  g1(15,22)=(-(T122*T124*getPowerDeriv(y(22)+params(10),T127,1)));
  g1(16,7)=(-((-T137)/(y(7)*y(7))));
  g1(16,15)=1;
  g1(16,22)=(-(1/exp(T101*params(4)*0.5*(1+params(4)))*getPowerDeriv((y(22)+params(10))/exp(T101*params(4)*0.5*(1+params(4))),T90,1)/y(7)));
  g1(17,8)=(-y(9));
  g1(17,9)=(-y(8));
  g1(17,10)=1;
  g1(18,28)=1;
  g1(19,26)=(-(((T157+y(26)*(1-T150))*(T150+y(26)*T628-T637)-(y(26)*T150-T157)*(T637+1-T150+y(26)*(-T628)))/((T157+y(26)*(1-T150))*(T157+y(26)*(1-T150)))));
  g1(19,27)=1;
  g1(20,17)=1;
  g1(20,18)=1;
  g1(20,19)=(-1);
  g1(21,18)=1-params(6);
  g1(21,19)=(-1);
  g1(21,22)=1;
  g1(22,17)=(-((-y(18))/(y(17)*y(17))));
  g1(22,18)=(-(1/y(17)));
  g1(22,23)=1;
  g1(23,10)=(-((-y(21))/(y(10)*y(10))));
  g1(23,21)=(-(1/y(10)));
  g1(23,25)=1;
  g1(24,16)=(-(T184*(-y(19))/(y(16)*y(16))));
  g1(24,19)=(-(T184*1/y(16)));
  g1(24,20)=(-(y(19)/y(16)*(-y(21))/(y(20)*y(20))*T555));
  g1(24,21)=(-(y(19)/y(16)*T555*1/y(20)));
  g1(24,26)=1;
  g1(25,6)=(-(1-params(6)));
  g1(25,24)=1;
  g1(26,24)=(-(((-(y(25)-y(24)))-(-(1-y(24))))/((y(25)-y(24))*(y(25)-y(24)))));
  g1(26,25)=(-((-(1-y(24)))/((y(25)-y(24))*(y(25)-y(24)))));
  g1(26,26)=(-T628);
  g1(27,6)=(-(y(10)*(T216+y(6)*(1-params(6))*(-(y(16)*y(28)*params(13)*(y(28)-1)/(y(16)*T156*T154*(-params(7))*T210)))/(T214*T214))));
  g1(27,10)=(-(y(6)*T216));
  g1(27,16)=(-(y(10)*y(6)*(1-params(6))*(-((y(16)*T156*T154*(-params(7))*T210*(y(28)*(y(28)-1)*y(6)*params(13)+(-(y(28)*params(13)*(y(28)-1))))-T206*T156*T154*(-params(7))*T210)/T519))/(T214*T214)));
  g1(27,17)=(-(y(10)*y(6)*(1-params(6))*(-(1/(y(16)*T156*T154*(-params(7))*T210)))/(T214*T214)));
  g1(27,20)=(-(y(10)*y(6)*(1-params(6))*(-((-(T206*y(16)*T156*T154*(-params(7))*(-y(21))/(y(20)*y(20))*T559))/T519))/(T214*T214)));
  g1(27,21)=1-y(10)*y(6)*(1-params(6))*(-((-(T206*y(16)*T156*T154*(-params(7))*T559*1/y(20)))/T519))/(T214*T214);
  g1(27,26)=(-(y(10)*y(6)*(1-params(6))*(-((-(T206*y(16)*T210*T154*(-params(7))*T636))/T519))/(T214*T214)));
  g1(27,28)=(-(y(10)*y(6)*(1-params(6))*(-(((-(y(16)*(params(13)*(y(28)-1)+y(28)*params(13))))+y(16)*((y(28)-1)*y(6)*params(13)+y(28)*y(6)*params(13)))/(y(16)*T156*T154*(-params(7))*T210)))/(T214*T214)));
  g1(28,16)=(-(T157*T210));
  g1(28,17)=1;
  g1(28,19)=(-(1-T150));
  g1(28,20)=(-(y(16)*T157*(-y(21))/(y(20)*y(20))*T559));
  g1(28,21)=(-(y(16)*T157*T559*1/y(20)));
  g1(28,26)=(-(y(16)*T210*T637+y(19)*(-T628)));
  g1(29,20)=1;
  g1(29,21)=(-T240);
  g1(29,26)=(-(y(21)*(T637+T235*T231*getPowerDeriv(y(26),T226,1)+T232*(-T622)*exp((-((params(8)/params(7)-T149)*(params(8)/params(7)-T149)))/2)/2.506628274631)*getPowerDeriv(T157+T232*T235,T239,1)));
  g1(30,3)=(-(T250*(-(y(7)*y(5)))/(y(5)*y(3)*y(5)*y(3))));
  g1(30,5)=(-(T250*(-(y(7)*y(3)))/(y(5)*y(3)*y(5)*y(3))));
  g1(30,7)=(-(T250*1/(y(5)*y(3))));
  g1(30,29)=(-(T94*y(42)/T249));
  g1(30,31)=1;
  g1(30,42)=(-(T94*(y(29)*T249-y(29)*y(42)*getPowerDeriv(y(42)+params(11),T90,1))/(T249*T249)));
  g1(31,31)=(-(1/y(31)/params(12)));
  g1(31,32)=1;
  g1(32,32)=(-(T109*(-(exp((-(y(32)*y(32)))/2)/2.506628274631))));
  g1(32,33)=1;
  g1(33,32)=(-(T109*(-(exp((-((y(32)-params(12))*(y(32)-params(12))))/2)/2.506628274631))));
  g1(33,34)=1;
  g1(34,3)=(-(T273*T271*y(5)/(y(7)*params(4))));
  g1(34,5)=(-(T273*T271*y(3)/(y(7)*params(4))));
  g1(34,7)=(-(T273*T271*(-(params(4)*y(5)*y(3)))/(y(7)*params(4)*y(7)*params(4))));
  g1(34,29)=1;
  g1(34,33)=(-(T273*T124*(-y(34))/(y(33)*y(33))));
  g1(34,34)=(-(T273*T124*1/y(33)));
  g1(34,42)=(-(T124*T271*getPowerDeriv(y(42)+params(11),T127,1)));
  g1(35,7)=(-((-T277)/(y(7)*y(7))));
  g1(35,35)=1;
  g1(35,42)=(-(1/exp(T101*params(4)*0.5*(1+params(4)))*getPowerDeriv((y(42)+params(11))/exp(T101*params(4)*0.5*(1+params(4))),T90,1)/y(7)));
  g1(36,8)=(-y(29));
  g1(36,29)=(-y(8));
  g1(36,30)=1;
  g1(37,48)=1;
  g1(38,46)=(-(((T293+y(46)*(1-T289))*(T289+y(46)*T854-T863)-(y(46)*T289-T293)*(T863+1-T289+y(46)*(-T854)))/((T293+y(46)*(1-T289))*(T293+y(46)*(1-T289)))));
  g1(38,47)=1;
  g1(39,37)=1;
  g1(39,38)=1;
  g1(39,39)=(-1);
  g1(40,38)=1-params(6);
  g1(40,39)=(-1);
  g1(40,42)=1;
  g1(41,37)=(-((-y(38))/(y(37)*y(37))));
  g1(41,38)=(-(1/y(37)));
  g1(41,43)=1;
  g1(42,30)=(-((-y(41))/(y(30)*y(30))));
  g1(42,41)=(-(1/y(30)));
  g1(42,45)=1;
  g1(43,36)=(-(T317*(-y(39))/(y(36)*y(36))));
  g1(43,39)=(-(T317*1/y(36)));
  g1(43,40)=(-(y(39)/y(36)*(-y(41))/(y(40)*y(40))*T782));
  g1(43,41)=(-(y(39)/y(36)*T782*1/y(40)));
  g1(43,46)=1;
  g1(44,6)=(-(1-params(6)));
  g1(44,44)=1;
  g1(45,44)=(-(((-(y(45)-y(44)))-(-(1-y(44))))/((y(45)-y(44))*(y(45)-y(44)))));
  g1(45,45)=(-((-(1-y(44)))/((y(45)-y(44))*(y(45)-y(44)))));
  g1(45,46)=(-T854);
  g1(46,6)=(-(y(30)*(T344+y(6)*(1-params(6))*(-(y(36)*y(48)*params(13)*(y(48)-1)/(y(36)*T154*(-params(7))*T292*T338)))/(T342*T342))));
  g1(46,30)=(-(y(6)*T344));
  g1(46,36)=(-(y(30)*y(6)*(1-params(6))*(-((y(36)*T154*(-params(7))*T292*T338*(y(48)*y(6)*params(13)*(y(48)-1)+(-(y(48)*params(13)*(y(48)-1))))-T336*T154*(-params(7))*T292*T338)/T750))/(T342*T342)));
  g1(46,37)=(-(y(30)*y(6)*(1-params(6))*(-(1/(y(36)*T154*(-params(7))*T292*T338)))/(T342*T342)));
  g1(46,40)=(-(y(30)*y(6)*(1-params(6))*(-((-(T336*y(36)*T154*(-params(7))*T292*(-y(41))/(y(40)*y(40))*T786))/T750))/(T342*T342)));
  g1(46,41)=1-y(30)*y(6)*(1-params(6))*(-((-(T336*y(36)*T154*(-params(7))*T292*T786*1/y(40)))/T750))/(T342*T342);
  g1(46,46)=(-(y(30)*y(6)*(1-params(6))*(-((-(T336*y(36)*T338*T154*(-params(7))*T862))/T750))/(T342*T342)));
  g1(46,48)=(-(y(30)*y(6)*(1-params(6))*(-(((-(y(36)*(params(13)*(y(48)-1)+params(13)*y(48))))+y(36)*(y(6)*params(13)*(y(48)-1)+y(6)*params(13)*y(48)))/(y(36)*T154*(-params(7))*T292*T338)))/(T342*T342)));
  g1(47,36)=(-(T293*T338));
  g1(47,37)=1;
  g1(47,39)=(-(1-T289));
  g1(47,40)=(-(y(36)*T293*(-y(41))/(y(40)*y(40))*T786));
  g1(47,41)=(-(y(36)*T293*T786*1/y(40)));
  g1(47,46)=(-(y(36)*T338*T863+y(39)*(-T854)));
  g1(48,40)=1;
  g1(48,41)=(-T359);
  g1(48,46)=(-(y(41)*(T863+T356*T231*getPowerDeriv(y(46),T226,1)+T354*(-T848)*exp((-((params(8)/params(7)-T288)*(params(8)/params(7)-T288)))/2)/2.506628274631)*getPowerDeriv(T293+T354*T356,T239,1)));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],48,2304);
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],48,110592);
end
end
end
end
