%
% Status : main Dynare file
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

if isoctave || matlab_ver_less_than('8.6')
    clear all
else
    clearvars -global
    clear_persistent_variables(fileparts(which('dynare')), false)
end
tic0 = tic;
% Save empty dates and dseries objects in memory.
dates('initialize');
dseries('initialize');
% Define global variables.
global M_ options_ oo_ estim_params_ bayestopt_ dataset_ dataset_info estimation_info ys0_ ex0_
options_ = [];
M_.fname = 'model';
M_.dynare_version = '4.5.4';
oo_.dynare_version = '4.5.4';
options_.dynare_version = '4.5.4';
%
% Some global variables initialization
%
global_initialization;
diary off;
diary('model.log');
M_.exo_names = 'eA';
M_.exo_names_tex = 'eA';
M_.exo_names_long = 'eA';
M_.exo_names = char(M_.exo_names, 'eR');
M_.exo_names_tex = char(M_.exo_names_tex, 'eR');
M_.exo_names_long = char(M_.exo_names_long, 'eR');
M_.endo_names = 'c';
M_.endo_names_tex = 'c';
M_.endo_names_long = 'c';
M_.endo_names = char(M_.endo_names, 'n');
M_.endo_names_tex = char(M_.endo_names_tex, 'n');
M_.endo_names_long = char(M_.endo_names_long, 'n');
M_.endo_names = char(M_.endo_names, 'w');
M_.endo_names_tex = char(M_.endo_names_tex, 'w');
M_.endo_names_long = char(M_.endo_names_long, 'w');
M_.endo_names = char(M_.endo_names, 'pi');
M_.endo_names_tex = char(M_.endo_names_tex, 'pi');
M_.endo_names_long = char(M_.endo_names_long, 'pi');
M_.endo_names = char(M_.endo_names, 'R');
M_.endo_names_tex = char(M_.endo_names_tex, 'R');
M_.endo_names_long = char(M_.endo_names_long, 'R');
M_.endo_names = char(M_.endo_names, 'm');
M_.endo_names_tex = char(M_.endo_names_tex, 'm');
M_.endo_names_long = char(M_.endo_names_long, 'm');
M_.endo_names = char(M_.endo_names, 'A');
M_.endo_names_tex = char(M_.endo_names_tex, 'A');
M_.endo_names_long = char(M_.endo_names_long, 'A');
M_.endo_names = char(M_.endo_names, 'p');
M_.endo_names_tex = char(M_.endo_names_tex, 'p');
M_.endo_names_long = char(M_.endo_names_long, 'p');
M_.endo_names = char(M_.endo_names, 'pmh');
M_.endo_names_tex = char(M_.endo_names_tex, 'pmh');
M_.endo_names_long = char(M_.endo_names_long, 'pmh');
M_.endo_names = char(M_.endo_names, 'pmhn');
M_.endo_names_tex = char(M_.endo_names_tex, 'pmhn');
M_.endo_names_long = char(M_.endo_names_long, 'pmhn');
M_.endo_names = char(M_.endo_names, 'zeh');
M_.endo_names_tex = char(M_.endo_names_tex, 'zeh');
M_.endo_names_long = char(M_.endo_names_long, 'zeh');
M_.endo_names = char(M_.endo_names, 'zsh');
M_.endo_names_tex = char(M_.endo_names_tex, 'zsh');
M_.endo_names_long = char(M_.endo_names_long, 'zsh');
M_.endo_names = char(M_.endo_names, 'Egh');
M_.endo_names_tex = char(M_.endo_names_tex, 'Egh');
M_.endo_names_long = char(M_.endo_names_long, 'Egh');
M_.endo_names = char(M_.endo_names, 'Ezgh');
M_.endo_names_tex = char(M_.endo_names_tex, 'Ezgh');
M_.endo_names_long = char(M_.endo_names_long, 'Ezgh');
M_.endo_names = char(M_.endo_names, 'hh');
M_.endo_names_tex = char(M_.endo_names_tex, 'hh');
M_.endo_names_long = char(M_.endo_names_long, 'hh');
M_.endo_names = char(M_.endo_names, 'ch');
M_.endo_names_tex = char(M_.endo_names_tex, 'ch');
M_.endo_names_long = char(M_.endo_names_long, 'ch');
M_.endo_names = char(M_.endo_names, 'qh');
M_.endo_names_tex = char(M_.endo_names_tex, 'qh');
M_.endo_names_long = char(M_.endo_names_long, 'qh');
M_.endo_names = char(M_.endo_names, 'invh');
M_.endo_names_tex = char(M_.endo_names_tex, 'invh');
M_.endo_names_long = char(M_.endo_names_long, 'invh');
M_.endo_names = char(M_.endo_names, 'ah');
M_.endo_names_tex = char(M_.endo_names_tex, 'ah');
M_.endo_names_long = char(M_.endo_names_long, 'ah');
M_.endo_names = char(M_.endo_names, 'ph');
M_.endo_names_tex = char(M_.endo_names_tex, 'ph');
M_.endo_names_long = char(M_.endo_names_long, 'ph');
M_.endo_names = char(M_.endo_names, 'psh');
M_.endo_names_tex = char(M_.endo_names_tex, 'psh');
M_.endo_names_long = char(M_.endo_names_long, 'psh');
M_.endo_names = char(M_.endo_names, 'yh');
M_.endo_names_tex = char(M_.endo_names_tex, 'yh');
M_.endo_names_long = char(M_.endo_names_long, 'yh');
M_.endo_names = char(M_.endo_names, 'ish');
M_.endo_names_tex = char(M_.endo_names_tex, 'ish');
M_.endo_names_long = char(M_.endo_names_long, 'ish');
M_.endo_names = char(M_.endo_names, 'rih');
M_.endo_names_tex = char(M_.endo_names_tex, 'rih');
M_.endo_names_long = char(M_.endo_names_long, 'rih');
M_.endo_names = char(M_.endo_names, 'muh');
M_.endo_names_tex = char(M_.endo_names_tex, 'muh');
M_.endo_names_long = char(M_.endo_names_long, 'muh');
M_.endo_names = char(M_.endo_names, 'vh');
M_.endo_names_tex = char(M_.endo_names_tex, 'vh');
M_.endo_names_long = char(M_.endo_names_long, 'vh');
M_.endo_names = char(M_.endo_names, 'ish_a');
M_.endo_names_tex = char(M_.endo_names_tex, 'ish\_a');
M_.endo_names_long = char(M_.endo_names_long, 'ish_a');
M_.endo_names = char(M_.endo_names, 'pih');
M_.endo_names_tex = char(M_.endo_names_tex, 'pih');
M_.endo_names_long = char(M_.endo_names_long, 'pih');
M_.endo_names = char(M_.endo_names, 'pml');
M_.endo_names_tex = char(M_.endo_names_tex, 'pml');
M_.endo_names_long = char(M_.endo_names_long, 'pml');
M_.endo_names = char(M_.endo_names, 'pmln');
M_.endo_names_tex = char(M_.endo_names_tex, 'pmln');
M_.endo_names_long = char(M_.endo_names_long, 'pmln');
M_.endo_names = char(M_.endo_names, 'zel');
M_.endo_names_tex = char(M_.endo_names_tex, 'zel');
M_.endo_names_long = char(M_.endo_names_long, 'zel');
M_.endo_names = char(M_.endo_names, 'zsl');
M_.endo_names_tex = char(M_.endo_names_tex, 'zsl');
M_.endo_names_long = char(M_.endo_names_long, 'zsl');
M_.endo_names = char(M_.endo_names, 'Egl');
M_.endo_names_tex = char(M_.endo_names_tex, 'Egl');
M_.endo_names_long = char(M_.endo_names_long, 'Egl');
M_.endo_names = char(M_.endo_names, 'Ezgl');
M_.endo_names_tex = char(M_.endo_names_tex, 'Ezgl');
M_.endo_names_long = char(M_.endo_names_long, 'Ezgl');
M_.endo_names = char(M_.endo_names, 'hl');
M_.endo_names_tex = char(M_.endo_names_tex, 'hl');
M_.endo_names_long = char(M_.endo_names_long, 'hl');
M_.endo_names = char(M_.endo_names, 'cl');
M_.endo_names_tex = char(M_.endo_names_tex, 'cl');
M_.endo_names_long = char(M_.endo_names_long, 'cl');
M_.endo_names = char(M_.endo_names, 'ql');
M_.endo_names_tex = char(M_.endo_names_tex, 'ql');
M_.endo_names_long = char(M_.endo_names_long, 'ql');
M_.endo_names = char(M_.endo_names, 'invl');
M_.endo_names_tex = char(M_.endo_names_tex, 'invl');
M_.endo_names_long = char(M_.endo_names_long, 'invl');
M_.endo_names = char(M_.endo_names, 'al');
M_.endo_names_tex = char(M_.endo_names_tex, 'al');
M_.endo_names_long = char(M_.endo_names_long, 'al');
M_.endo_names = char(M_.endo_names, 'pl');
M_.endo_names_tex = char(M_.endo_names_tex, 'pl');
M_.endo_names_long = char(M_.endo_names_long, 'pl');
M_.endo_names = char(M_.endo_names, 'psl');
M_.endo_names_tex = char(M_.endo_names_tex, 'psl');
M_.endo_names_long = char(M_.endo_names_long, 'psl');
M_.endo_names = char(M_.endo_names, 'yl');
M_.endo_names_tex = char(M_.endo_names_tex, 'yl');
M_.endo_names_long = char(M_.endo_names_long, 'yl');
M_.endo_names = char(M_.endo_names, 'isl');
M_.endo_names_tex = char(M_.endo_names_tex, 'isl');
M_.endo_names_long = char(M_.endo_names_long, 'isl');
M_.endo_names = char(M_.endo_names, 'ril');
M_.endo_names_tex = char(M_.endo_names_tex, 'ril');
M_.endo_names_long = char(M_.endo_names_long, 'ril');
M_.endo_names = char(M_.endo_names, 'mul');
M_.endo_names_tex = char(M_.endo_names_tex, 'mul');
M_.endo_names_long = char(M_.endo_names_long, 'mul');
M_.endo_names = char(M_.endo_names, 'vl');
M_.endo_names_tex = char(M_.endo_names_tex, 'vl');
M_.endo_names_long = char(M_.endo_names_long, 'vl');
M_.endo_names = char(M_.endo_names, 'isl_a');
M_.endo_names_tex = char(M_.endo_names_tex, 'isl\_a');
M_.endo_names_long = char(M_.endo_names_long, 'isl_a');
M_.endo_names = char(M_.endo_names, 'pil');
M_.endo_names_tex = char(M_.endo_names_tex, 'pil');
M_.endo_names_long = char(M_.endo_names_long, 'pil');
M_.endo_partitions = struct();
M_.param_names = 'sigma';
M_.param_names_tex = 'sigma';
M_.param_names_long = 'sigma';
M_.param_names = char(M_.param_names, 'eta');
M_.param_names_tex = char(M_.param_names_tex, 'eta');
M_.param_names_long = char(M_.param_names_long, 'eta');
M_.param_names = char(M_.param_names, 'beta');
M_.param_names_tex = char(M_.param_names_tex, 'beta');
M_.param_names_long = char(M_.param_names_long, 'beta');
M_.param_names = char(M_.param_names, 'alpha');
M_.param_names_tex = char(M_.param_names_tex, 'alpha');
M_.param_names_long = char(M_.param_names_long, 'alpha');
M_.param_names = char(M_.param_names, 'omega');
M_.param_names_tex = char(M_.param_names_tex, 'omega');
M_.param_names_long = char(M_.param_names_long, 'omega');
M_.param_names = char(M_.param_names, 'delta');
M_.param_names_tex = char(M_.param_names_tex, 'delta');
M_.param_names_long = char(M_.param_names_long, 'delta');
M_.param_names = char(M_.param_names, 'theta');
M_.param_names_tex = char(M_.param_names_tex, 'theta');
M_.param_names_long = char(M_.param_names_long, 'theta');
M_.param_names = char(M_.param_names, 'sig_v');
M_.param_names_tex = char(M_.param_names_tex, 'sig\_v');
M_.param_names_long = char(M_.param_names_long, 'sig_v');
M_.param_names = char(M_.param_names, 'varphi');
M_.param_names_tex = char(M_.param_names_tex, 'varphi');
M_.param_names_long = char(M_.param_names_long, 'varphi');
M_.param_names = char(M_.param_names, 'phih');
M_.param_names_tex = char(M_.param_names_tex, 'phih');
M_.param_names_long = char(M_.param_names_long, 'phih');
M_.param_names = char(M_.param_names, 'phil');
M_.param_names_tex = char(M_.param_names_tex, 'phil');
M_.param_names_long = char(M_.param_names_long, 'phil');
M_.param_names = char(M_.param_names, 'sig_c');
M_.param_names_tex = char(M_.param_names_tex, 'sig\_c');
M_.param_names_long = char(M_.param_names_long, 'sig_c');
M_.param_names = char(M_.param_names, 'psi');
M_.param_names_tex = char(M_.param_names_tex, 'psi');
M_.param_names_long = char(M_.param_names_long, 'psi');
M_.param_names = char(M_.param_names, 'rho_A');
M_.param_names_tex = char(M_.param_names_tex, 'rho\_A');
M_.param_names_long = char(M_.param_names_long, 'rho_A');
M_.param_names = char(M_.param_names, 'phi_r');
M_.param_names_tex = char(M_.param_names_tex, 'phi\_r');
M_.param_names_long = char(M_.param_names_long, 'phi_r');
M_.param_names = char(M_.param_names, 'phi_pi');
M_.param_names_tex = char(M_.param_names_tex, 'phi\_pi');
M_.param_names_long = char(M_.param_names_long, 'phi_pi');
M_.param_names = char(M_.param_names, 'Asig');
M_.param_names_tex = char(M_.param_names_tex, 'Asig');
M_.param_names_long = char(M_.param_names_long, 'Asig');
M_.param_names = char(M_.param_names, 'Rsig');
M_.param_names_tex = char(M_.param_names_tex, 'Rsig');
M_.param_names_long = char(M_.param_names_long, 'Rsig');
M_.param_names = char(M_.param_names, 'omega1');
M_.param_names_tex = char(M_.param_names_tex, 'omega1');
M_.param_names_long = char(M_.param_names_long, 'omega1');
M_.param_names = char(M_.param_names, 'omega2');
M_.param_names_tex = char(M_.param_names_tex, 'omega2');
M_.param_names_long = char(M_.param_names_long, 'omega2');
M_.param_partitions = struct();
M_.exo_det_nbr = 0;
M_.exo_nbr = 2;
M_.endo_nbr = 48;
M_.param_nbr = 20;
M_.orig_endo_nbr = 48;
M_.aux_vars = [];
M_.Sigma_e = zeros(2, 2);
M_.Correlation_matrix = eye(2, 2);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = 1;
M_.det_shocks = [];
options_.block=0;
options_.bytecode=0;
options_.use_dll=0;
M_.hessian_eq_zero = 1;
erase_compiled_function('model_static');
erase_compiled_function('model_dynamic');
M_.orig_eq_nbr = 48;
M_.eq_nbr = 48;
M_.ramsey_eq_nbr = 0;
M_.set_auxiliary_variables = exist(['./' M_.fname '_set_auxiliary_variables.m'], 'file') == 2;
M_.lead_lag_incidence = [
 1 9 0;
 0 10 0;
 0 11 0;
 0 12 57;
 2 13 0;
 0 14 58;
 3 15 0;
 4 16 0;
 0 17 0;
 0 18 59;
 0 19 0;
 0 20 0;
 0 21 0;
 0 22 0;
 0 23 0;
 0 24 60;
 0 25 0;
 5 26 0;
 0 27 0;
 6 28 0;
 0 29 0;
 0 30 0;
 0 31 0;
 0 32 0;
 0 33 0;
 0 34 0;
 0 35 0;
 0 36 61;
 0 37 0;
 0 38 62;
 0 39 0;
 0 40 0;
 0 41 0;
 0 42 0;
 0 43 0;
 0 44 63;
 0 45 0;
 7 46 0;
 0 47 0;
 8 48 0;
 0 49 0;
 0 50 0;
 0 51 0;
 0 52 0;
 0 53 0;
 0 54 0;
 0 55 0;
 0 56 64;]';
M_.nstatic = 32;
M_.nfwrd   = 8;
M_.npred   = 8;
M_.nboth   = 0;
M_.nsfwrd   = 8;
M_.nspred   = 8;
M_.ndynamic   = 16;
M_.equations_tags = {
};
M_.static_and_dynamic_models_differ = 0;
M_.exo_names_orig_ord = [1:2];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(48, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(2, 1);
M_.params = NaN(20, 1);
M_.NNZDerivatives = [178; -1; -1];
M_.params( 1 ) = 1.000;
sigma = M_.params( 1 );
M_.params( 2 ) = 2.5;
eta = M_.params( 2 );
M_.params( 3 ) = 0.99;
beta = M_.params( 3 );
M_.params( 4 ) = 0.67;
alpha = M_.params( 4 );
M_.params( 5 ) = 1;
omega = M_.params( 5 );
M_.params( 6 ) = 0.011;
delta = M_.params( 6 );
M_.params( 7 ) = 6.7;
theta = M_.params( 7 );
M_.params( 8 ) = 0.804;
sig_v = M_.params( 8 );
M_.params( 9 ) = 0.3;
varphi = M_.params( 9 );
M_.params( 10 ) = 0.7;
phih = M_.params( 10 );
M_.params( 11 ) = 0.2;
phil = M_.params( 11 );
M_.params( 12 ) = 0.05;
sig_c = M_.params( 12 );
M_.params( 13 ) = 10;
psi = M_.params( 13 );
M_.params( 14 ) = 0.9;
rho_A = M_.params( 14 );
M_.params( 17 ) = 0.010;
Asig = M_.params( 17 );
M_.params( 18 ) = 0.01;
Rsig = M_.params( 18 );
M_.params( 15 ) = 0.8;
phi_r = M_.params( 15 );
M_.params( 16 ) = 1.5;
phi_pi = M_.params( 16 );
M_.params( 19 ) = 0.5;
omega1 = M_.params( 19 );
M_.params( 20 ) = 0.5;
omega2 = M_.params( 20 );
steady;
oo_.dr.eigval = check(M_,options_,oo_);
%
% SHOCKS instructions
%
M_.exo_det_length = 0;
M_.Sigma_e(2, 2) = 1;
options_.ar = 4;
options_.irf = 30;
options_.order = 1;
options_.pruning = 1;
var_list_ = char('ish','isl','qh','ql','invh','invl','vh','vl','muh','mul','ril','rih');
info = stoch_simul(var_list_);
save('model_results.mat', 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save('model_results.mat', 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save('model_results.mat', 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save('model_results.mat', 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save('model_results.mat', 'estimation_info', '-append');
end
if exist('dataset_info', 'var') == 1
  save('model_results.mat', 'dataset_info', '-append');
end
if exist('oo_recursive_', 'var') == 1
  save('model_results.mat', 'oo_recursive_', '-append');
end


disp(['Total computing time : ' dynsec2hms(toc(tic0)) ]);
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
diary off
