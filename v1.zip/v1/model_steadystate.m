function [ys,check] = model_steadystate(ys,exe) 

global M_  sigma eta beta alpha omega ...
           delta theta sig_v...
		   varphi phih phil sig_c...
		   psi rho_A phi_r phi_pi Asig Rsig...
           omega1 omega2 ...
           c n w pi R m A p...
           pmh pmhn zeh zsh Egh Ezgh hh...
	       ch qh invh ah ph psh yh ish rih muh vh ish_a pih...
	       pml pmln zel zsl Egl Ezgl hl...
	       cl ql invl al pl psl yl isl ril mul vl isl_a pil;
           
   sigma   = M_.params(1);  
   eta     = M_.params(2);  
   beta    = M_.params(3);  
   alpha   = M_.params(4);  
   omega   = M_.params(5);  
   delta   = M_.params(6);
   theta   = M_.params(7);   
   sig_v   = M_.params(8);
   varphi  = M_.params(9);
   phih    = M_.params(10);  
   phil    = M_.params(11); 
   sig_c   = M_.params(12); 
   psi     = M_.params(13); 
   rho_A   = M_.params(14);  
   phi_r   = M_.params(15);   
   phi_pi  = M_.params(16);  
   Asig    = M_.params(17);  
   Rsig    = M_.params(18); 
   omega1  = M_.params(19); 
   omega2  = M_.params(20);
    
   
   check       = 0;
   
    A      =1;
    m      =beta;
    R      =1/beta;
    pi     =1;
    pih    =1;
    pil    =1;
    rih    =(1-delta)*m;
    ril    =(1-delta)*m;
    
    options  = optimset('LargeScale','off','display','off',...
           'MaxIter',5000,'MaxFunEvals',5000,'TolX',1e-10,...
           'TolFun',1e-10);
   
    X=[1.9400,1.9400,0.8663,-2.8448,1.4276,1.4278,1,0.9624,...
       1.1924, 2.0777, 2.0084,0.9682,1.0353,1.0064,...
        1.5557, 1.5557, 1.3525,6.0640,1.0000,1.0000,1,0.9573,...
        1.2975,1.6593 ,1.6437 ,0.9658,1.0566,1.2377,...
         1.0974,2.1419,1,3.2393,18.8855,1];
 
   
    X=fsolve(@sect,X,options);
    
pmh=X(1);
pmhn=X(2);
zeh=X(3);
zsh=X(4);
Egh=X(5);
Ezgh=X(6);
ch=X(7);
qh=X(8);
ah=X(9);
ph=X(10);
psh=X(11);
yh=X(12);
muh=X(13);
vh=X(14);


pml=X(15);
pmln=X(16);
zel=X(17);
zsl=X(18);
Egl=X(19);
Ezgl=X(20);
cl=X(21);
ql=X(22);
al=X(23);
pl=X(24);
psl=X(25);
yl=X(26);
mul=X(27);
vl=X(28);

hh=X(29);
hl=X(30);

c=X(31);
n=X(32);
w=X(33);
p=X(34);

invh=ah-qh;
ish=invh/qh;
ish_a   =(vh*normcdf(log(vh)/sig_v)-(exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v)))...
        /((exp(sig_v^2/2)*normcdf(log(vh)/sig_v-sig_v))+vh*(1-normcdf(log(vh)/sig_v)));

invl=al-ql;
isl=invl/ql;
isl_a=(vl*normcdf(log(vl)/sig_v)-(exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v)))...
        /((exp(sig_v^2/2)*normcdf(log(vl)/sig_v-sig_v))+vl*(1-normcdf(log(vl)/sig_v))); 

    
    
    ys     = [c n w pi R m A p...
           pmh pmhn zeh zsh Egh Ezgh hh...
	       ch qh invh ah ph psh yh ish rih muh vh ish_a pih...
	       pml pmln zel zsl Egl Ezgl hl...
	       cl ql invl al pl psl yl isl ril mul vl isl_a pil]';

end
