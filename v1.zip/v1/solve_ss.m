global sigma eta beta alpha omega delta zeta theta  ... 
	   varphi phi1 phi2 omega1 omega2 sig;
   
   sigma=1.001;
   eta=2.5;
   beta=0.99;
   alpha=0.8;
   omega=1;
   delta=0.025;
   zeta=0.15;
   theta=5;
   varphi=0.30;
   phi1=0;
   phi2=0.8;
   omega1=0.5; 
   omega2=0.5;
   sig=0.05;
   
    p1     =0.9846;
    p2     =1.16386;
    c1     =1;
    a1     =1.75;
    a2     =1.75;
    a      =a1+a2;
    pt     =(omega1*(a1/a)^zeta*p1^(1-theta)...
           + omega2*(a2/a)^zeta*p2^(1-theta))^(1/(1-theta));
    c2     =c1/(((a1/a)^zeta*(p1/pt)^(-theta))/((a2/a)^zeta*(p2/pt)^(-theta)));
    c      =(omega1*(a1/a)^(zeta/theta)*c1^(1-1/theta)...
           +omega2*(a2/a)^(zeta/theta)*c2^(1-1/theta))^(1/(1-1/theta));
    inv1   =a1-c1;
    is1    =inv1/c1;
    y1     =c1*(1+is1*delta);
    n1     =((y1+phi1)/exp(0.5*alpha*(1+alpha)*sig^2))^(1/alpha);
    inv2   =a2-c2;
    is2    =inv2/c2;
    y2     =c2*(1+is2*delta);
    n2     =((y2+phi2)/exp(0.5*alpha*(1+alpha)*sig^2))^(1/alpha);
    n      =n1+n2;
    w      =omega*c^sigma*n^eta;
    ze1     = p1*c1/((y1+phi1)^(1/alpha))*beta/w;
    zs1     =(log(ze1)+0.5*sig^2)/sig;
    Egam1   =1 + varphi/(1-varphi)*(1-normcdf(zs1));
    Emc1    =(1 + varphi/(1-varphi)*(1-normcdf(zs1-sig)))*(w/(beta*alpha))*(y1+phi1)^((1-alpha)/alpha);
    v1      =(1-delta)*beta*Emc1;
    ri1     =v1/Emc1;
    mkp1    =Egam1*p1/Emc1;
    ze2     = p2*c2/((y2+phi2)^(1/alpha))*beta/w;
    zs2     =(log(ze2)+0.5*sig^2)/sig;
    Egam2   =1 + varphi/(1-varphi)*(1-normcdf(zs2));
    Emc2    =(1 + varphi/(1-varphi)*(1-normcdf(zs2-sig)))*(w/(beta*alpha))*(y2+phi2)^((1-alpha)/alpha);
    v2      =(1-delta)*beta*Emc2;
    ri2     =v2/Emc2;
    mkp2    =Egam2*p2/Emc2;
 
     options     = optimset('LargeScale','off','display','off',...
               'MaxIter',5000,'MaxFunEvals',5000,'TolX',1e-10,...
                'TolFun',1e-10);
            
    X=[c,n,w,a,pt,p1,p2,c1,n1,ze1,zs1,Egam1,v1,mkp1,ri1,Emc1,a1,inv1,is1,y1,...
      c2,n2,ze2,zs2,Egam2,v2,mkp2,ri2,Emc2,a2,inv2,is2,y2];
    X=fsolve(@model_ss,X,options);        
            
            