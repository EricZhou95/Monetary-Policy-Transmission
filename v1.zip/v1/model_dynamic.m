function [residual, g1, g2, g3] = model_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [nperiods by M_.exo_nbr] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   steady_state  [M_.endo_nbr by 1] double       vector of steady state values
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations.
%                                          Dynare may prepend auxiliary equations, see M_.aux_vars
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence followed by the ones in M_.exo_names
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence followed by the ones in M_.exo_names
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence followed by the ones in M_.exo_names
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(48, 1);
T22 = y(2)^params(15);
T28 = 1/params(3)*y(12)^params(16);
T30 = T28^(1-params(15));
T43 = params(5)*y(9)^params(1);
T46 = y(10)^params(2);
T63 = params(19)^(-params(19));
T69 = params(20)^(-params(20));
T70 = T63*y(24)^params(19)*T69;
T72 = y(44)^params(20);
T77 = y(28)^params(19);
T79 = y(48)^params(20);
T101 = 1/params(4);
T102 = (y(30)+params(10))^T101;
T103 = y(17)*y(30)/T102;
T105 = y(15)/(y(13)*y(11));
T112 = params(12)^2;
T120 = params(9)/(1-params(9));
T133 = y(22)/y(21);
T135 = y(13)*y(11)/(y(15)*params(4));
T138 = (1-params(4))/params(4);
T139 = (y(30)+params(10))^T138;
T148 = ((y(30)+params(10))/exp(T112*params(4)*0.5*(1+params(4))))^T101;
T162 = log(y(34))/params(8);
T163 = normcdf(T162,0,1);
T165 = params(8)^2;
T167 = exp(T165/2);
T169 = normcdf(T162-params(8),0,1);
T170 = T167*T169;
T196 = y(29)/y(28);
T198 = T196^params(7);
T226 = y(25)-y(24)*y(36)*params(13)*(y(36)-1)+y(61)*y(58)*params(13)*(y(61)-1)*y(60);
T230 = T196^(-params(7));
T232 = y(24)*T169*T167*(-params(7))*T230;
T234 = 1+T226/T232;
T236 = (1-params(6))*1/T234;
T246 = 1-1/params(7);
T251 = exp(T165/(2*params(7)^2));
T252 = y(34)^T246*T251;
T255 = normcdf(params(8)/params(7)-T162,0,1);
T259 = 1/(1-params(7));
T260 = (T170+T252*T255)^T259;
T269 = (y(50)+params(11))^T101;
T270 = y(37)*y(50)/T269;
T291 = y(42)/y(41);
T293 = (y(50)+params(11))^T138;
T297 = ((y(50)+params(11))/exp(T112*params(4)*0.5*(1+params(4))))^T101;
T310 = log(y(54))/params(8);
T311 = normcdf(T310,0,1);
T314 = normcdf(T310-params(8),0,1);
T315 = T167*T314;
T339 = y(49)/y(48);
T340 = T339^params(7);
T365 = y(45)-y(44)*y(56)*params(13)*(y(56)-1)+y(64)*y(58)*params(13)*(y(64)-1)*y(63);
T367 = T339^(-params(7));
T369 = y(44)*T167*(-params(7))*T314*T367;
T371 = 1+T365/T369;
T373 = (1-params(6))*1/T371;
T383 = T251*y(54)^T246;
T385 = normcdf(params(8)/params(7)-T310,0,1);
T388 = (T315+T383*T385)^T259;
lhs =log(y(15));
rhs =params(14)*log(y(3))+params(17)*x(it_, 1);
residual(1)= lhs-rhs;
lhs =y(13);
rhs =T22*T30*exp(params(18)*x(it_, 2));
residual(2)= lhs-rhs;
lhs =y(11);
rhs =T43*T46;
residual(3)= lhs-rhs;
lhs =1;
rhs =y(13)*y(58)/y(57);
residual(4)= lhs-rhs;
lhs =y(14);
rhs =params(3)*(y(9)/y(1))^(-params(1));
residual(5)= lhs-rhs;
lhs =y(9);
rhs =T70*T72;
residual(6)= lhs-rhs;
lhs =y(16);
rhs =T77*T79;
residual(7)= lhs-rhs;
lhs =y(24)/y(44);
rhs =params(19)*y(48)/(params(20)*y(28));
residual(8)= lhs-rhs;
lhs =y(12);
rhs =y(16)/y(4);
residual(9)= lhs-rhs;
lhs =y(10);
rhs =y(23)+y(43);
residual(10)= lhs-rhs;
lhs =y(19);
rhs =T103*T105;
residual(11)= lhs-rhs;
lhs =y(20);
rhs =(log(y(19))+0.5*T112)/params(12);
residual(12)= lhs-rhs;
lhs =y(21);
rhs =1+T120*(1-normcdf(y(20),0,1));
residual(13)= lhs-rhs;
lhs =y(22);
rhs =1+T120*(1-normcdf(y(20)-params(12),0,1));
residual(14)= lhs-rhs;
lhs =y(17);
rhs =T133*T135*T139;
residual(15)= lhs-rhs;
lhs =y(23);
rhs =T148/y(15);
residual(16)= lhs-rhs;
lhs =y(18);
rhs =y(16)*y(17);
residual(17)= lhs-rhs;
lhs =y(36);
rhs =y(28)/y(6);
residual(18)= lhs-rhs;
lhs =y(35);
rhs =(y(34)*T163-T170)/(T170+y(34)*(1-T163));
residual(19)= lhs-rhs;
lhs =y(26);
rhs =y(27)-y(25);
residual(20)= lhs-rhs;
lhs =y(30);
rhs =y(27)-(1-params(6))*y(5);
residual(21)= lhs-rhs;
lhs =y(31);
rhs =y(26)/y(25);
residual(22)= lhs-rhs;
lhs =y(33);
rhs =y(29)/y(18);
residual(23)= lhs-rhs;
lhs =y(34);
rhs =y(27)/y(24)*T198;
residual(24)= lhs-rhs;
lhs =y(32);
rhs =y(58)*(1-params(6))*y(59)/y(18);
residual(25)= lhs-rhs;
lhs =0;
rhs =T163-1+(1-y(32))/(y(33)-y(32));
residual(26)= lhs-rhs;
lhs =y(29);
rhs =y(59)*y(58)*T236;
residual(27)= lhs-rhs;
lhs =y(25);
rhs =y(24)*T170*T230+(1-T163)*y(27);
residual(28)= lhs-rhs;
lhs =y(28);
rhs =y(29)*T260;
residual(29)= lhs-rhs;
lhs =y(39);
rhs =T105*T270;
residual(30)= lhs-rhs;
lhs =y(40);
rhs =(0.5*T112+log(y(39)))/params(12);
residual(31)= lhs-rhs;
lhs =y(41);
rhs =1+T120*(1-normcdf(y(40),0,1));
residual(32)= lhs-rhs;
lhs =y(42);
rhs =1+T120*(1-normcdf(y(40)-params(12),0,1));
residual(33)= lhs-rhs;
lhs =y(37);
rhs =T135*T291*T293;
residual(34)= lhs-rhs;
lhs =y(43);
rhs =T297/y(15);
residual(35)= lhs-rhs;
lhs =y(38);
rhs =y(16)*y(37);
residual(36)= lhs-rhs;
lhs =y(56);
rhs =y(48)/y(8);
residual(37)= lhs-rhs;
lhs =y(55);
rhs =(y(54)*T311-T315)/(T315+y(54)*(1-T311));
residual(38)= lhs-rhs;
lhs =y(46);
rhs =y(47)-y(45);
residual(39)= lhs-rhs;
lhs =y(50);
rhs =y(47)-(1-params(6))*y(7);
residual(40)= lhs-rhs;
lhs =y(51);
rhs =y(46)/y(45);
residual(41)= lhs-rhs;
lhs =y(53);
rhs =y(49)/y(38);
residual(42)= lhs-rhs;
lhs =y(54);
rhs =y(47)/y(44)*T340;
residual(43)= lhs-rhs;
lhs =y(52);
rhs =y(58)*(1-params(6))*y(62)/y(38);
residual(44)= lhs-rhs;
lhs =0;
rhs =T311-1+(1-y(52))/(y(53)-y(52));
residual(45)= lhs-rhs;
lhs =y(49);
rhs =y(62)*y(58)*T373;
residual(46)= lhs-rhs;
lhs =y(45);
rhs =y(44)*T315*T367+(1-T311)*y(47);
residual(47)= lhs-rhs;
lhs =y(48);
rhs =y(49)*T388;
residual(48)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(48, 66);

  %
  % Jacobian matrix
  %

T394 = getPowerDeriv(y(9)/y(1),(-params(1)),1);
T580 = T232*T232;
T630 = getPowerDeriv(T196,params(7),1);
T634 = getPowerDeriv(T196,(-params(7)),1);
T696 = 1/y(34)/params(8);
T702 = T696*exp((-(T162*T162))/2)/2.506628274631;
T710 = T696*exp((-((T162-params(8))*(T162-params(8))))/2)/2.506628274631;
T711 = T167*T710;
T836 = T369*T369;
T881 = getPowerDeriv(T339,params(7),1);
T885 = getPowerDeriv(T339,(-params(7)),1);
T946 = 1/y(54)/params(8);
T952 = T946*exp((-(T310*T310))/2)/2.506628274631;
T960 = T946*exp((-((T310-params(8))*(T310-params(8))))/2)/2.506628274631;
T961 = T167*T960;
  g1(1,3)=(-(params(14)*1/y(3)));
  g1(1,15)=1/y(15);
  g1(1,65)=(-params(17));
  g1(2,12)=(-(exp(params(18)*x(it_, 2))*T22*1/params(3)*getPowerDeriv(y(12),params(16),1)*getPowerDeriv(T28,1-params(15),1)));
  g1(2,2)=(-(exp(params(18)*x(it_, 2))*T30*getPowerDeriv(y(2),params(15),1)));
  g1(2,13)=1;
  g1(2,66)=(-(T22*T30*params(18)*exp(params(18)*x(it_, 2))));
  g1(3,9)=(-(T46*params(5)*getPowerDeriv(y(9),params(1),1)));
  g1(3,10)=(-(T43*getPowerDeriv(y(10),params(2),1)));
  g1(3,11)=1;
  g1(4,57)=(-((-(y(13)*y(58)))/(y(57)*y(57))));
  g1(4,13)=(-(y(58)/y(57)));
  g1(4,58)=(-(y(13)/y(57)));
  g1(5,1)=(-(params(3)*(-y(9))/(y(1)*y(1))*T394));
  g1(5,9)=(-(params(3)*T394*1/y(1)));
  g1(5,14)=1;
  g1(6,9)=1;
  g1(6,24)=(-(T72*T69*T63*getPowerDeriv(y(24),params(19),1)));
  g1(6,44)=(-(T70*getPowerDeriv(y(44),params(20),1)));
  g1(7,16)=1;
  g1(7,28)=(-(T79*getPowerDeriv(y(28),params(19),1)));
  g1(7,48)=(-(T77*getPowerDeriv(y(48),params(20),1)));
  g1(8,24)=1/y(44);
  g1(8,28)=(-((-(params(20)*params(19)*y(48)))/(params(20)*y(28)*params(20)*y(28))));
  g1(8,44)=(-y(24))/(y(44)*y(44));
  g1(8,48)=(-(params(19)/(params(20)*y(28))));
  g1(9,12)=1;
  g1(9,4)=(-((-y(16))/(y(4)*y(4))));
  g1(9,16)=(-(1/y(4)));
  g1(10,10)=1;
  g1(10,23)=(-1);
  g1(10,43)=(-1);
  g1(11,11)=(-(T103*(-(y(15)*y(13)))/(y(13)*y(11)*y(13)*y(11))));
  g1(11,13)=(-(T103*(-(y(15)*y(11)))/(y(13)*y(11)*y(13)*y(11))));
  g1(11,15)=(-(T103*1/(y(13)*y(11))));
  g1(11,17)=(-(T105*y(30)/T102));
  g1(11,19)=1;
  g1(11,30)=(-(T105*(y(17)*T102-y(17)*y(30)*getPowerDeriv(y(30)+params(10),T101,1))/(T102*T102)));
  g1(12,19)=(-(1/y(19)/params(12)));
  g1(12,20)=1;
  g1(13,20)=(-(T120*(-(exp((-(y(20)*y(20)))/2)/2.506628274631))));
  g1(13,21)=1;
  g1(14,20)=(-(T120*(-(exp((-((y(20)-params(12))*(y(20)-params(12))))/2)/2.506628274631))));
  g1(14,22)=1;
  g1(15,11)=(-(T139*T133*y(13)/(y(15)*params(4))));
  g1(15,13)=(-(T139*T133*y(11)/(y(15)*params(4))));
  g1(15,15)=(-(T139*T133*(-(params(4)*y(13)*y(11)))/(y(15)*params(4)*y(15)*params(4))));
  g1(15,17)=1;
  g1(15,21)=(-(T139*T135*(-y(22))/(y(21)*y(21))));
  g1(15,22)=(-(T139*T135*1/y(21)));
  g1(15,30)=(-(T133*T135*getPowerDeriv(y(30)+params(10),T138,1)));
  g1(16,15)=(-((-T148)/(y(15)*y(15))));
  g1(16,23)=1;
  g1(16,30)=(-(1/exp(T112*params(4)*0.5*(1+params(4)))*getPowerDeriv((y(30)+params(10))/exp(T112*params(4)*0.5*(1+params(4))),T101,1)/y(15)));
  g1(17,16)=(-y(17));
  g1(17,17)=(-y(16));
  g1(17,18)=1;
  g1(18,6)=(-((-y(28))/(y(6)*y(6))));
  g1(18,28)=(-(1/y(6)));
  g1(18,36)=1;
  g1(19,34)=(-(((T170+y(34)*(1-T163))*(T163+y(34)*T702-T711)-(y(34)*T163-T170)*(T711+1-T163+y(34)*(-T702)))/((T170+y(34)*(1-T163))*(T170+y(34)*(1-T163)))));
  g1(19,35)=1;
  g1(20,25)=1;
  g1(20,26)=1;
  g1(20,27)=(-1);
  g1(21,5)=1-params(6);
  g1(21,27)=(-1);
  g1(21,30)=1;
  g1(22,25)=(-((-y(26))/(y(25)*y(25))));
  g1(22,26)=(-(1/y(25)));
  g1(22,31)=1;
  g1(23,18)=(-((-y(29))/(y(18)*y(18))));
  g1(23,29)=(-(1/y(18)));
  g1(23,33)=1;
  g1(24,24)=(-(T198*(-y(27))/(y(24)*y(24))));
  g1(24,27)=(-(T198*1/y(24)));
  g1(24,28)=(-(y(27)/y(24)*(-y(29))/(y(28)*y(28))*T630));
  g1(24,29)=(-(y(27)/y(24)*T630*1/y(28)));
  g1(24,34)=1;
  g1(25,58)=(-((1-params(6))*y(59)/y(18)));
  g1(25,18)=(-(y(58)*(1-params(6))*(-y(59))/(y(18)*y(18))));
  g1(25,59)=(-(y(58)*(1-params(6))*1/y(18)));
  g1(25,32)=1;
  g1(26,32)=(-(((-(y(33)-y(32)))-(-(1-y(32))))/((y(33)-y(32))*(y(33)-y(32)))));
  g1(26,33)=(-((-(1-y(32)))/((y(33)-y(32))*(y(33)-y(32)))));
  g1(26,34)=(-T702);
  g1(27,58)=(-(y(59)*(T236+y(58)*(1-params(6))*(-(y(60)*y(61)*params(13)*(y(61)-1)/T232))/(T234*T234))));
  g1(27,59)=(-(y(58)*T236));
  g1(27,24)=(-(y(59)*y(58)*(1-params(6))*(-((T232*(-(y(36)*params(13)*(y(36)-1)))-T226*T169*T167*(-params(7))*T230)/T580))/(T234*T234)));
  g1(27,60)=(-(y(59)*y(58)*(1-params(6))*(-(y(61)*y(58)*params(13)*(y(61)-1)/T232))/(T234*T234)));
  g1(27,25)=(-(y(59)*y(58)*(1-params(6))*(-(1/T232))/(T234*T234)));
  g1(27,28)=(-(y(59)*y(58)*(1-params(6))*(-((-(T226*y(24)*T169*T167*(-params(7))*(-y(29))/(y(28)*y(28))*T634))/T580))/(T234*T234)));
  g1(27,29)=1-y(59)*y(58)*(1-params(6))*(-((-(T226*y(24)*T169*T167*(-params(7))*T634*1/y(28)))/T580))/(T234*T234);
  g1(27,34)=(-(y(59)*y(58)*(1-params(6))*(-((-(T226*y(24)*T230*T167*(-params(7))*T710))/T580))/(T234*T234)));
  g1(27,36)=(-(y(59)*y(58)*(1-params(6))*(-((-(y(24)*(params(13)*(y(36)-1)+y(36)*params(13))))/T232))/(T234*T234)));
  g1(27,61)=(-(y(59)*y(58)*(1-params(6))*(-(y(60)*(y(58)*params(13)*(y(61)-1)+y(58)*params(13)*y(61))/T232))/(T234*T234)));
  g1(28,24)=(-(T170*T230));
  g1(28,25)=1;
  g1(28,27)=(-(1-T163));
  g1(28,28)=(-(y(24)*T170*(-y(29))/(y(28)*y(28))*T634));
  g1(28,29)=(-(y(24)*T170*T634*1/y(28)));
  g1(28,34)=(-(y(24)*T230*T711+y(27)*(-T702)));
  g1(29,28)=1;
  g1(29,29)=(-T260);
  g1(29,34)=(-(y(29)*(T711+T255*T251*getPowerDeriv(y(34),T246,1)+T252*(-T696)*exp((-((params(8)/params(7)-T162)*(params(8)/params(7)-T162)))/2)/2.506628274631)*getPowerDeriv(T170+T252*T255,T259,1)));
  g1(30,11)=(-(T270*(-(y(15)*y(13)))/(y(13)*y(11)*y(13)*y(11))));
  g1(30,13)=(-(T270*(-(y(15)*y(11)))/(y(13)*y(11)*y(13)*y(11))));
  g1(30,15)=(-(T270*1/(y(13)*y(11))));
  g1(30,37)=(-(T105*y(50)/T269));
  g1(30,39)=1;
  g1(30,50)=(-(T105*(y(37)*T269-y(37)*y(50)*getPowerDeriv(y(50)+params(11),T101,1))/(T269*T269)));
  g1(31,39)=(-(1/y(39)/params(12)));
  g1(31,40)=1;
  g1(32,40)=(-(T120*(-(exp((-(y(40)*y(40)))/2)/2.506628274631))));
  g1(32,41)=1;
  g1(33,40)=(-(T120*(-(exp((-((y(40)-params(12))*(y(40)-params(12))))/2)/2.506628274631))));
  g1(33,42)=1;
  g1(34,11)=(-(T293*T291*y(13)/(y(15)*params(4))));
  g1(34,13)=(-(T293*T291*y(11)/(y(15)*params(4))));
  g1(34,15)=(-(T293*T291*(-(params(4)*y(13)*y(11)))/(y(15)*params(4)*y(15)*params(4))));
  g1(34,37)=1;
  g1(34,41)=(-(T293*T135*(-y(42))/(y(41)*y(41))));
  g1(34,42)=(-(T293*T135*1/y(41)));
  g1(34,50)=(-(T135*T291*getPowerDeriv(y(50)+params(11),T138,1)));
  g1(35,15)=(-((-T297)/(y(15)*y(15))));
  g1(35,43)=1;
  g1(35,50)=(-(1/exp(T112*params(4)*0.5*(1+params(4)))*getPowerDeriv((y(50)+params(11))/exp(T112*params(4)*0.5*(1+params(4))),T101,1)/y(15)));
  g1(36,16)=(-y(37));
  g1(36,37)=(-y(16));
  g1(36,38)=1;
  g1(37,8)=(-((-y(48))/(y(8)*y(8))));
  g1(37,48)=(-(1/y(8)));
  g1(37,56)=1;
  g1(38,54)=(-(((T315+y(54)*(1-T311))*(T311+y(54)*T952-T961)-(y(54)*T311-T315)*(T961+1-T311+y(54)*(-T952)))/((T315+y(54)*(1-T311))*(T315+y(54)*(1-T311)))));
  g1(38,55)=1;
  g1(39,45)=1;
  g1(39,46)=1;
  g1(39,47)=(-1);
  g1(40,7)=1-params(6);
  g1(40,47)=(-1);
  g1(40,50)=1;
  g1(41,45)=(-((-y(46))/(y(45)*y(45))));
  g1(41,46)=(-(1/y(45)));
  g1(41,51)=1;
  g1(42,38)=(-((-y(49))/(y(38)*y(38))));
  g1(42,49)=(-(1/y(38)));
  g1(42,53)=1;
  g1(43,44)=(-(T340*(-y(47))/(y(44)*y(44))));
  g1(43,47)=(-(T340*1/y(44)));
  g1(43,48)=(-(y(47)/y(44)*(-y(49))/(y(48)*y(48))*T881));
  g1(43,49)=(-(y(47)/y(44)*T881*1/y(48)));
  g1(43,54)=1;
  g1(44,58)=(-((1-params(6))*y(62)/y(38)));
  g1(44,38)=(-(y(58)*(1-params(6))*(-y(62))/(y(38)*y(38))));
  g1(44,62)=(-(y(58)*(1-params(6))*1/y(38)));
  g1(44,52)=1;
  g1(45,52)=(-(((-(y(53)-y(52)))-(-(1-y(52))))/((y(53)-y(52))*(y(53)-y(52)))));
  g1(45,53)=(-((-(1-y(52)))/((y(53)-y(52))*(y(53)-y(52)))));
  g1(45,54)=(-T952);
  g1(46,58)=(-(y(62)*(T373+y(58)*(1-params(6))*(-(y(63)*y(64)*params(13)*(y(64)-1)/T369))/(T371*T371))));
  g1(46,62)=(-(y(58)*T373));
  g1(46,44)=(-(y(62)*y(58)*(1-params(6))*(-((T369*(-(y(56)*params(13)*(y(56)-1)))-T365*T167*(-params(7))*T314*T367)/T836))/(T371*T371)));
  g1(46,63)=(-(y(62)*y(58)*(1-params(6))*(-(y(64)*y(58)*params(13)*(y(64)-1)/T369))/(T371*T371)));
  g1(46,45)=(-(y(62)*y(58)*(1-params(6))*(-(1/T369))/(T371*T371)));
  g1(46,48)=(-(y(62)*y(58)*(1-params(6))*(-((-(T365*y(44)*T167*(-params(7))*T314*(-y(49))/(y(48)*y(48))*T885))/T836))/(T371*T371)));
  g1(46,49)=1-y(62)*y(58)*(1-params(6))*(-((-(T365*y(44)*T167*(-params(7))*T314*T885*1/y(48)))/T836))/(T371*T371);
  g1(46,54)=(-(y(62)*y(58)*(1-params(6))*(-((-(T365*y(44)*T367*T167*(-params(7))*T960))/T836))/(T371*T371)));
  g1(46,56)=(-(y(62)*y(58)*(1-params(6))*(-((-(y(44)*(params(13)*(y(56)-1)+params(13)*y(56))))/T369))/(T371*T371)));
  g1(46,64)=(-(y(62)*y(58)*(1-params(6))*(-(y(63)*(y(58)*params(13)*(y(64)-1)+y(58)*params(13)*y(64))/T369))/(T371*T371)));
  g1(47,44)=(-(T315*T367));
  g1(47,45)=1;
  g1(47,47)=(-(1-T311));
  g1(47,48)=(-(y(44)*T315*(-y(49))/(y(48)*y(48))*T885));
  g1(47,49)=(-(y(44)*T315*T885*1/y(48)));
  g1(47,54)=(-(y(44)*T367*T961+y(47)*(-T952)));
  g1(48,48)=1;
  g1(48,49)=(-T388);
  g1(48,54)=(-(y(49)*(T961+T385*T251*getPowerDeriv(y(54),T246,1)+T383*(-T946)*exp((-((params(8)/params(7)-T310)*(params(8)/params(7)-T310)))/2)/2.506628274631)*getPowerDeriv(T315+T383*T385,T259,1)));

if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],48,4356);
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],48,287496);
end
end
end
end
